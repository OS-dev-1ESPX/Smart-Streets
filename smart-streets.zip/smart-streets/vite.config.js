import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
const proxy = { '/api': { target: 'http://127.0.0.1:3001', changeOrigin: true, rewrite: (path) => path.replace(/^\/api/, '') } }
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { proxy, strictPort: true },
  preview: { proxy, strictPort: true },
})
